frontend-nanodegree-arcade-game
===============================

#about classic arcade game:
In Front-End Web Developer Nanodegree Program, I made classic arcade game project after download source project from this link "https://github.com/udacity/frontend-nanodegree-arcade-game". In this game I want to make the player move up, down, right and left in proportion to the squares through the arrows and the player can avoid the bugs that move from left to right. If the player reaches water in the top without touching the bugs wins the game, but if touched by the bugs back down and tries again. After opening the project folder I opened a file called app.js and made the required modifications to run the game.

#How to play:
After you open the folder "frontend-nanodegree-arcade-game-master". Then Click the "index.html" file to start the game. Then you can move through the arrows to avoid the bugs and reach the water so you won the game and show a message Congratulations and I hope you enjoy it.

#about me
Hossam hossam
hossamkabeel@gmail.com
